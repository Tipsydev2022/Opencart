<?php define('JOURNAL3_BUILD', '895ca1b8'); 
