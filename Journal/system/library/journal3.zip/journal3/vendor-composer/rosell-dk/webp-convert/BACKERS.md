
# Backers

WebP Convert is an MIT-licensed open source project. It is free and always will be.

How is it financed then? Well, it isn't exactly. However, some people choose to support the development by buying the developer a cup of coffee, and some go even further, by becoming backers. Backers are nice folks making recurring monthly donations, and by doing this, they give me an excuse to put more work into the library than I really should.

To become a backer yourself, visit [my page at patreon](https://www.patreon.com/rosell)


## Backers via Patron

| Name                  | Date       | Message (max 70 chars, plain text only) |
| --------------------- | ---------- | ----------------------------------------------------------------------- |
| Tammy Valgardson      | 2018-12-27 |          |
| Max Kreminsky         | 2019-08-02 |          |

<sub>I reserve the right to disallow inappropriate messages. No Trump hooting or bashing here, please. And don't be aggressive, obscene or anything unpleasant. But I don't have to point that out, do I?</sub>

## Generous backers via Patron

Generous backers will get their names listed here, along with a message - max 100 chars, and it may contain one link (the link url does not count any chars).

There are no generous backers yet. [Be the first!](https://www.patreon.com/rosell)

<sub>
I reserve the right to disallow inappropriate messages and links. No xxx sites or anything freaky or fishy, please. You may however advertise non-freaky-or-fishy things, if you wish. Just remember the audience. No point in trying to sell shoes here</sub>
