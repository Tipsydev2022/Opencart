# HTTP Factory for Guzzle

HTTP factory implemented for [Guzzle](https://github.com/guzzle/psr7).
