# Change Log


## 1.0.0 - 2016-01-26

### Removed

- PSR-7 dependency


## 1.0.0-RC1 - 2016-01-12

### Added

- Tests for full coverage

## Changed

- Updated package files
- Clarified wait method behavior
- Contributing guide moved to the documentation


## 0.1.1 - 2015-12-24

## Added

- Fulfilled and Rejected promise implementations


## 0.1.0 - 2015-12-13

## Added

- Promise interface
